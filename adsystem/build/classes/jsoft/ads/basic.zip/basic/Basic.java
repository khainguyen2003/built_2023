package jsoft.ads.basic;

import java.sql.*;

import jsoft.*;
import java.util.*;
import java.sql.*;

public interface Basic {

	//PreparedStatement pre đã được biên dịch và đã truyền giá trị
	public boolean add(PreparedStatement pre);
	public boolean edit(PreparedStatement pre);
	public boolean del(PreparedStatement pre);
	
	// Phương thức lấy 1 kết quả
	public ResultSet get(String sql, int id);
	public ResultSet get(String sql, String name, String pass);
	// Phương thức lấy nhiều kết quả
	public ResultSet gets(String sql);
	
	public ArrayList<ResultSet> getReList(String multiSelect);
	
	// Chia sẻ bộ quản lý kết nối giữa các basic với nhau
	public ConnectionPool getCP();
	// Ra lệch các đối tượng phải trả lại kết nối
	public void releaseConnection();
	
}