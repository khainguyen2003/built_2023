package jsoft.ads.user;

public enum USER_SORT_TYPE {
	NAME,
	FULLNAME,
	ADDRESS,
	CREATED,
	MODIFIED,
	UPDATE
}
