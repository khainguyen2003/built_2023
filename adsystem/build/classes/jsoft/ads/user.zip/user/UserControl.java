package jsoft.ads.user;
import jsoft.*;
import jsoft.object.UserObject;

import java.util.*;
import org.javatuples.*;
public class UserControl {
	private UserModel um;
	
	public UserControl(ConnectionPool cp) {
		this.um = new UserModel(cp);
	}
	
	public boolean addUser(UserObject item) {
		return this.um.addUser(item);
	}
	public boolean editUser(UserObject item) {
		return this.um.editUser(item);
	}
	public boolean delUser(UserObject item) {
		return this.um.delUser(item);
	}
	public ArrayList<String> viewUsers(Quartet<UserObject, Short, Byte, USER_SORT_TYPE> infors) {
		// Lấy dữ liêu
		UserObject similar = infors.getValue0();
		short page = infors.getValue1();
		byte total = infors.getValue2();
		USER_SORT_TYPE ust = infors.getValue3();
		
		ArrayList<UserObject> datas = this.um.getUserObjects(similar, page, total, ust);
		
		return UserLibrary.viewUser(datas);
	}
	
	public static void main(String[] args) {
		UserControl uc = new UserControl(null);
		Quartet<UserObject, Short, Byte, USER_SORT_TYPE> infors = new Quartet<>(null, (short)1, (byte)10, USER_SORT_TYPE.NAME);
		
		ArrayList view = uc.viewUsers(infors);
		
		System.out.println(view);
	}
}
