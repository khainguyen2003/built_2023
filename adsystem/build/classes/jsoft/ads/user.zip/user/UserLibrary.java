package jsoft.ads.user;
import jsoft.object.*;
import java.util.*;
import org.javatuples.*;

public class UserLibrary {
	public static ArrayList<String> viewUser(ArrayList<UserObject> items) {
		StringBuilder tmp = new StringBuilder();
		tmp.append("<table class=\"table table-striped\">");
		tmp.append("<thead>");
		tmp.append("<tr>");
		tmp.append("<th scope=\"col\">#</th>");
		tmp.append("<th scope=\"col\">Tên đăng nhập</th>");
		tmp.append("<th scope=\"col\">Tên đầy đủ</th>");
		tmp.append("<th scope=\"col\">Hộp thư</th>");
		tmp.append("<th scope=\"col\">Điện thoại</th>");
		tmp.append("<th scope=\"col\">Địa chỉ</th>");
		tmp.append("<th scope=\"col\" colspan=\"3\">Thực hiện</th>");
		tmp.append("</tr>");
		tmp.append("</thead>");
		tmp.append("<tbody>");
		items.forEach(item-> {
			tmp.append("<tr>");
			tmp.append("<th scope=\"row\">"+item.getUser_id()+"</th>");
			tmp.append("<td>"+ item.getUser_name() +"</td>");
			tmp.append("<td>").append(item.getUser_fullname()).append("</td>");
			tmp.append("<td>").append(item.getUser_email()).append("</td>");
			tmp.append("<td>").append(item.getUser_homephone()).append("</td>");
			tmp.append("<td>").append(item.getUser_address()).append("</td>");
			tmp.append("<td>Chi tiết</td>");
			tmp.append("<td>Sửa</td>");
			tmp.append("<td>Xóa</td>");
			tmp.append("</tr>");
		});
		// Khi dùng với servlet thì không dùng kí tự \n
		tmp.append("</tbody>");
		tmp.append("</table>\n");
		
		ArrayList<String> view = new ArrayList<>();
		view.add(tmp.toString());
		return view;
	}
}
