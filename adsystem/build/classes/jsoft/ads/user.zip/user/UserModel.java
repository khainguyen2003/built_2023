package jsoft.ads.user;

import jsoft.*;
import org.javatuples.*;
import jsoft.object.*;

import java.util.*;
import java.sql.*;

public class UserModel {
	private User u;
	
	public UserModel(ConnectionPool cp) {
		this.u= new UserImpl(cp);
	}
	
	protected void finalize()throws Throwable{
		this.u=null;
	}

	//***********************Chuyen huong dieu khien tu User Impl*****************************************
	public boolean addUser(UserObject item) {
		return this.u.addUser(item);
	}
	
	public boolean editUser(UserObject item) {
		return this.u.editUser(item);
	}
	
	public boolean delUser(UserObject item) {
		return this.u.delUser(item);
	}
	
	
	//****************************************************************
	
	public UserObject getUserObject(int id) {
		//Gan gia tri khoi tao cho doi tuong UserObject
		UserObject item = null ;
		
		//Lay ban ghi 
		ResultSet rs = this.u.getUser(id);
		
		
		//Chuyen doi ban ghi thanh doi tuong
		if (rs!=null) {
			try {
				if (rs.next()) {
					item = new UserObject();
					item.setUser_id(rs.getInt("user_id"));
					item.setUser_name(rs.getString("user_name"));
					item.setUser_fullname(rs.getString("user_fullname"));
					item.setUser_email(rs.getString("user_email"));
					item.setUser_address(rs.getString("user_address"));
					item.setUser_homephone(rs.getString("user_homephone"));
					item.setUser_officephone(rs.getString("user_officephone"));
					item.setUser_mobilephone(rs.getString("user_mobilephone"));
					item.setUser_permission(rs.getByte("user_permission"));
					
					item.setUser_parent_id(rs.getInt("user_parent_id"));
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return item;
	}
	
	// Xử lý đăng nhập
	public UserObject getUserObject(String username, String userpass) {
		//Gan gia tri khoi tao cho doi tuong UserObject
		UserObject item = null ;
		
		//Lay ban ghi 
		ResultSet rs = this.u.getUser(username, userpass);
		
		
		//Chuyen doi ban ghi thanh doi tuong
		if (rs!=null) {
			try {
				if (rs.next()) {
					item = new UserObject();
					item.setUser_id(rs.getInt("user_id"));
					item.setUser_name(rs.getString("user_name"));
					item.setUser_fullname(rs.getString("user_fullname"));
					item.setUser_email(rs.getString("user_email"));
					item.setUser_address(rs.getString("user_address"));
					item.setUser_homephone(rs.getString("user_homephone"));
					item.setUser_officephone(rs.getString("user_officephone"));
					item.setUser_mobilephone(rs.getString("user_mobilephone"));
					item.setUser_permission(rs.getByte("user_permission"));
					
					item.setUser_parent_id(rs.getInt("user_parent_id"));
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return item;
	}
	// Phương thức có thể gọi nhiều câu lệnh select
	public ArrayList<UserObject> getUserObjects(UserObject similar, short page, byte total, USER_SORT_TYPE type) {
		
		//Gan gia tri khoi tao cho doi tuong UserObject
		ArrayList<UserObject> items = new ArrayList<>();
		UserObject item = null ;
		
		//Lay ban ghi 
		int at = (page-1)*total;
		ArrayList<ResultSet> res = this.u.getUsers(similar, at, total, type);
		ResultSet rs = res.get(0);
		
		//Chuyen doi ban ghi thanh doi tuong
		if (rs!=null) {
			try {
				while (rs.next()) {
					item = new UserObject();
					item.setUser_id(rs.getInt("user_id"));
					item.setUser_name(rs.getString("user_name"));
					item.setUser_fullname(rs.getString("user_fullname"));
					item.setUser_email(rs.getString("user_email"));
					item.setUser_address(rs.getString("user_address"));
					item.setUser_homephone(rs.getString("user_homephone"));
					item.setUser_officephone(rs.getString("user_officephone"));
					item.setUser_mobilephone(rs.getString("user_mobilephone"));
					item.setUser_permission(rs.getByte("user_permission"));
					
					item.setUser_parent_id(rs.getInt("user_parent_id"));
					
					
					// Dua doi tuong vao tap hop
					items.add(item);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return items;
	}
	
	public static void main(String[] args) {
		ConnectionPool cp = new ConnectionPoolImpl();
		
		UserModel um = new UserModel(cp);
		
		ArrayList<UserObject> items = um.getUserObjects(null, (short) 1, (byte) 20, USER_SORT_TYPE.FULLNAME);
		
		items.forEach(item -> System.out.println(item));
	};
	
}

